# Hướng dẫn triển khai (Deployment Guide)

Tài liệu này hướng dẫn bạn triển khai trang web truyện ra môi trường thực để mọi người có thể truy cập. Các bước dưới đây áp dụng cho máy chủ Linux Ubuntu/Debian, nhưng bạn có thể điều chỉnh tương tự cho các nền tảng khác hoặc dịch vụ PaaS.

## 1. Chuẩn bị máy chủ và tên miền

1. **Chọn dịch vụ hosting**: Thuê máy chủ ảo (VPS) như DigitalOcean, Linode, Vultr… hoặc dùng dịch vụ PaaS như Render, Railway, Fly.io. Ở đây chúng tôi giả định bạn dùng VPS.
2. **Cài đặt hệ điều hành**: Tạo máy chủ Ubuntu 22.04 LTS (hoặc tương tự). Cập nhật hệ thống bằng:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```
3. **Trỏ tên miền**: Mua một tên miền và cấu hình bản ghi DNS trỏ tới IP của máy chủ.

## 2. Cài đặt các phần mềm cần thiết

Bạn cần cài đặt Python, một WSGI server (Gunicorn) và một reverse proxy (Nginx). Chạy các lệnh sau trên máy chủ:

```bash
sudo apt install -y python3 python3-venv python3-pip nginx
```

## 3. Tải mã nguồn và cấu trúc thư mục

1. **Sao chép dự án**: Bạn có thể upload thư mục `src/` (mã nguồn) và `data/` (cơ sở dữ liệu) vào máy chủ bằng SCP hoặc Git. Ví dụ, bạn có thể nén thư mục rồi tải lên:
   ```bash
   scp -r src data youruser@yourserver:/home/youruser/story_site
   ```
2. **Tạo môi trường ảo**: Vào thư mục mã nguồn và tạo môi trường Python:
   ```bash
   cd /home/youruser/story_site/src
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

## 4. Thiết lập biến môi trường

Tạo file `.env` trong thư mục `src` (cùng cấp với `app.py`) để chứa các biến cấu hình nhạy cảm như mật khẩu upload và secret key. Ví dụ:

```ini
UPLOAD_PASSWORD=your_upload_password
SECRET_KEY=your_random_secret_key
DATABASE_URL=/home/youruser/story_site/data/stories.db
```

Sau đó, bạn có thể sử dụng thư viện `python-dotenv` hoặc tự đọc file `.env` trong `app.py` để cấu hình. (Trong mã nguồn hiện tại, biến môi trường `UPLOAD_PASSWORD` được sử dụng trực tiếp.)

## 5. Thiết lập Gunicorn và Systemd

Gunicorn sẽ chạy ứng dụng Flask. Tạo file dịch vụ systemd tại `/etc/systemd/system/story_site.service` với nội dung sau (thay đường dẫn cho phù hợp):

```ini
[Unit]
Description=Gunicorn instance to serve Story Site
After=network.target

[Service]
User=youruser
Group=www-data
WorkingDirectory=/home/youruser/story_site/src
Environment="PATH=/home/youruser/story_site/src/venv/bin"
EnvironmentFile=/home/youruser/story_site/src/.env
ExecStart=/home/youruser/story_site/src/venv/bin/gunicorn --workers 3 --bind unix:/home/youruser/story_site/story_site.sock app:app

[Install]
WantedBy=multi-user.target
```

Chạy các lệnh sau để kích hoạt dịch vụ:

```bash
sudo systemctl daemon-reload
sudo systemctl start story_site
sudo systemctl enable story_site
```

## 6. Cấu hình Nginx

Tạo file cấu hình Nginx `/etc/nginx/sites-available/story_site`:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /static/ {
        alias /home/youruser/story_site/src/static/;
    }

    location / {
        include proxy_params;
        proxy_pass http://unix:/home/youruser/story_site/story_site.sock;
    }
}
```

Liên kết file này vào `sites-enabled` và reload Nginx:

```bash
sudo ln -s /etc/nginx/sites-available/story_site /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

Sau khi kiểm tra trang bằng domain, bạn có thể cài đặt SSL miễn phí với Certbot:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

## 7. Bảo mật

* **Tắt debug**: Trong `app.py`, bảo đảm không dùng `debug=True` trong môi trường production.
* **Ẩn secret key**: Đặt `SECRET_KEY` và `UPLOAD_PASSWORD` trong biến môi trường, không ghi thẳng trong mã nguồn【945246927297181†L204-L269】.
* **Chống XSS và SQL Injection**: Flask/Jinja đã auto‑escape template để giảm nguy cơ XSS【913772578757602†L50-L77】. Sử dụng SQLAlchemy và tham số hoá truy vấn để tránh SQL Injection【868250200358756†L174-L206】.
* **Chống CSRF**: Sử dụng các token CSRF cho những form thay đổi dữ liệu hoặc dùng thư viện Flask‑WTF【913772578757602†L104-L131】.
* **Cập nhật phần mềm**: Thường xuyên cập nhật Python và thư viện để vá lỗ hổng【868250200358756†L174-L206】.

## 8. Kiểm thử và giám sát

* Kiểm thử toàn bộ tính năng trước khi public: tạo truyện, chỉnh sửa, đánh giá, tìm kiếm, xác thực upload…
* Theo dõi log bằng `journalctl -u story_site` để phát hiện lỗi.
* Định kỳ sao lưu file cơ sở dữ liệu trong thư mục `data/` để tránh mất dữ liệu.

## 9. Dịch vụ PaaS (tuỳ chọn)

Nếu muốn đơn giản hoá quá trình triển khai, bạn có thể dùng dịch vụ PaaS:

1. **Heroku**: cần tạo `Procfile` với nội dung `web: gunicorn app:app` và push code lên Heroku, khai báo biến môi trường, gắn Postgres (để thay SQLite).
2. **Render/Fly.io/Railway**: các nền tảng này hỗ trợ deploy container hoặc Python app. Bạn chỉ cần import repo, đặt biến môi trường và chọn vùng triển khai.

Các bước chi tiết có thể khác nhau tuỳ nhà cung cấp nhưng về cơ bản bạn vẫn cần một WSGI server và khai báo biến môi trường.

---

Sau khi hoàn thành các bước trên, trang web của bạn sẽ được triển khai ổn định và an toàn hơn. Bạn có thể tiếp tục cải tiến tính năng và giao diện, nhưng hãy luôn kiểm thử kỹ trước khi cập nhật trên máy chủ.